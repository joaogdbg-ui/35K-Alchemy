import test from 'node:test';
import assert from 'node:assert/strict';
import {ORGANIC_V71} from '../src/organic-pack-v71.js';
import {ORGANIC_ART_V71} from '../src/organic-art-v71.js';

test('V71 ships 40 individual discoveries, never 40 alternate names for old elements',()=>{
 assert.equal(ORGANIC_V71.items.length,40);
 assert.equal(ORGANIC_V71.recipes.length,40);
 assert.equal(new Set(ORGANIC_V71.items.map(i=>i.id)).size,40);
 assert.equal(new Set(ORGANIC_V71.items.map(i=>i.name.toLowerCase())).size,40);
 assert.equal(new Set(ORGANIC_V71.recipes.map(r=>[...r.slice(0,2)].sort().join('|'))).size,40);
});

test('Each new item has exactly one discoverable recipe and its own original SVG',()=>{
 const outcomes=new Set(ORGANIC_V71.recipes.map(r=>r[2]));
 for(const item of ORGANIC_V71.items){
   assert.ok(outcomes.has(item.id));
   const svg=ORGANIC_ART_V71[item.name.toLowerCase()];
   assert.ok(svg&&svg.includes('<path'),`missing art for ${item.name}`);
   assert.doesNotMatch(svg,/<image\b|<script\b/i);
 }
 assert.equal(outcomes.size,40);
 assert.equal(new Set(Object.values(ORGANIC_ART_V71)).size,40);
});
