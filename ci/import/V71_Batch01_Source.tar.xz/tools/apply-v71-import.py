#!/usr/bin/env python3
"""Integrate V71 Batch 01 into existing V70 source with exact guardrails.
Run once on GitHub Actions after the 40-piece source tarball is extracted.
"""
from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]

def replace(path,old,new,expected=1):
 p=root/path
 source=p.read_text(encoding='utf-8')
 actual=source.count(old)
 if actual!=expected:
  raise SystemExit(f'Unsafe V71 integration: {path}: {actual} replacements for {old[:90]!r}, expected {expected}')
 p.write_text(source.replace(old,new),encoding='utf-8')

replace('client/src/app.js',"import { ORGANIC_ART_V70 } from './organic-art-v70.js';", "import { ORGANIC_V71 } from './organic-pack-v71.js';\nimport { ORGANIC_ART_V71 } from './organic-art-v71.js';\nimport { ORGANIC_ART_V70 } from './organic-art-v70.js';")
replace('client/src/app.js','ORGANIC_V67,ORGANIC_V68]);','ORGANIC_V67,ORGANIC_V68,ORGANIC_V71]);')
replace('client/src/app.js','ORGANIC_ART_V70[itemName]||ORGANIC_ART_V69[itemName]','ORGANIC_ART_V71[itemName]||ORGANIC_ART_V70[itemName]||ORGANIC_ART_V69[itemName]')
replace('tools/build-standalone.py', 'organicart70=(root/',
 "organic71=(root/'client/src/organic-pack-v71.js').read_text(encoding='utf-8').replace('export const ORGANIC_V71 =','const ORGANIC_V71 =')\n"
 "organicart71=(root/'client/src/organic-art-v71.js').read_text(encoding='utf-8').replace('export const ORGANIC_ART_V71 =','const ORGANIC_ART_V71 =')\n"
 'organicart70=(root/')
replace('tools/build-standalone.py', "app=app.replace(\"import { ORGANIC_ART_V70 }", 
 "app=app.replace(\"import { ORGANIC_V71 } from './organic-pack-v71.js';\",'const {ORGANIC_V71}=window.__gameverseOrganic71;')\n"
 "app=app.replace(\"import { ORGANIC_ART_V71 } from './organic-art-v71.js';\",'const {ORGANIC_ART_V71}=window.__gameverseOrganicArt71;')\n"
 "app=app.replace(\"import { ORGANIC_ART_V70 }")
replace('tools/build-standalone.py',"js='window.__gameverseOrganicArt70=(function(){'",
 "js='window.__gameverseOrganic71=(function(){'+organic71+'return {ORGANIC_V71};})();\\n'+'window.__gameverseOrganicArt71=(function(){'+organicart71+'return {ORGANIC_ART_V71};})();\\n'+'window.__gameverseOrganicArt70=(function(){'")
replace('tools/build-standalone.py', "out=root/'35K_Alchemy_V70_Offline.html'", "out=root/'35K_Alchemy_V71_Offline.html'")
replace('tools/build-standalone.py',"subprocess.run(['node','tools/validate-v70.mjs','--quiet'],cwd=root,check=True)","subprocess.run(['node','tools/validate-v70.mjs','--quiet'],cwd=root,check=True)\nsubprocess.run(['node','tools/validate-v71.mjs'],cwd=root,check=True)")
replace('tools/build-standalone.py','V70 UI','V71 UI')
replace('tools/prepare-android-web.py','V70','V71',expected=5)
config=root/'package.json'
d=json.loads(config.read_text(encoding='utf-8'))
assert d['version']=='0.70.0', d['version']
d['version']='0.71.0'
config.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
readme=root/'README.md'
r=readme.read_text(encoding='utf-8')
assert '# 35K Alchemy — V69' in r or '# 35K Alchemy — V70' in r
r=r.replace('# 35K Alchemy — V69','# 35K Alchemy — V71 (Batch 01: 40 of 200)',1).replace('# 35K Alchemy — V70','# 35K Alchemy — V71 (Batch 01: 40 of 200)',1)
anchor='## Instalar Android (link permanente)'
assert anchor in r
r=r.replace(anchor,'''## V71 — Batch 01 / 200

- **40 new named, fully recipe-backed elements**; not alternate redraws or aliases.
- **40 subject-specific vector illustrations** from reviewed coastal and culinary designs.
- Catalog: **5,212 elements and 13,549 fixed recipes**; IDs and results from V70 remain unchanged.
- 160 further new elements are planned for this V71 editorial batch, not yet delivered.
- See [HANDOFF_V71.md](HANDOFF_V71.md) and `shared/v71-approved.json` for content provenance.

'''+anchor)
readme.write_text(r,encoding='utf-8')
assert (root/'client/assets/v71/tide-pool-viewer.svg').exists()
print('Integrated V71 Batch 01: 40 new elements + 40 images, configured for Android APK')
