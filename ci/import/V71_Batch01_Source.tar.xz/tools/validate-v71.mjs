import {readFileSync,readdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {DATA} from '../client/src/legacy-data.js';
import {PACK} from '../client/src/creative-pack.js';
import {buildCatalog} from '../client/src/catalog-integrity.js';
import {ORGANIC_V71} from '../client/src/organic-pack-v71.js';
import {ORGANIC_ART_V71} from '../client/src/organic-art-v71.js';
const assert=(p,m)=>{if(!p)throw Error('V71: '+m)};
const manifest=JSON.parse(readFileSync('shared/v71-approved.json','utf8'));
const packs=[PACK];
for(const name of readdirSync('client/src').filter(x=>/^(gaming|organic)-pack-v\d+\.js$/.test(x)&&x!=='organic-pack-v71.js')){
 const m=await import('../client/src/'+name);
 packs.push(Object.values(m)[0]);
}
const base=buildCatalog(DATA,packs);
assert(base.items.length===5172&&base.recipes.size===13509,'V70 baseline drift');
const merged=buildCatalog(DATA,[...packs,ORGANIC_V71]);
assert(merged.items.length===5212&&merged.recipes.size===13549,'catalog count drift');
assert(manifest.new_items.length===40&&ORGANIC_V71.items.length===40&&ORGANIC_V71.recipes.length===40,'must contain 40 new discoveries');
assert(Object.keys(ORGANIC_ART_V71).length===40,'missing or unexpected art');
const oldNames=new Set(base.items.map(i=>i.name.toLowerCase()));
const hashes=new Set(),ids=new Set(),names=new Set();
for(const e of manifest.new_items){
 assert(!ids.has(e.id)&&!names.has(e.name.toLowerCase()),'duplicate batch item');
 ids.add(e.id);names.add(e.name.toLowerCase());
 assert(!oldNames.has(e.name.toLowerCase()),'existing name reused');
 assert(e.art_mode==='unique-silhouette-vector','not a subject-specific vector');
 const svg=readFileSync(e.path,'utf8');
 assert(svg.includes('<svg')&&svg.includes('viewBox="0 0 100 100"'),'not full SVG: '+e.name);
 assert(!/<script\b|<image\b|<foreignObject\b|<text\b|onload\s*=|href\s*=|<animate\b/i.test(svg),'unsafe or bitmap SVG');
 const digest=createHash('sha256').update(svg).digest('hex');
 assert(digest===e.sha256,'SVG source changed: '+e.name);
 assert(!hashes.has(digest),'duplicate SVG');hashes.add(digest);
 assert(ORGANIC_ART_V71[e.name.toLowerCase()]===svg,'embedded SVG drift: '+e.name);
 const item=ORGANIC_V71.items.find(x=>x.id===e.id);
 assert(item?.name===e.name,'item ID or name drift');
 assert(ORGANIC_V71.recipes.some(x=>x[2]===e.id),'new item has no recipe');
}
for(const [a,b,out] of ORGANIC_V71.recipes){
 assert(a!==out&&b!==out,'self reference');
 assert(base.items.some(x=>x.id===a)&&base.items.some(x=>x.id===b),'new recipes must use pre-existing ingredients');
}
const app=readFileSync('client/src/app.js','utf8');
assert(app.includes('ORGANIC_ART_V71[itemName]||ORGANIC_ART_V70[itemName]'),'V71 art is not highest priority');
assert(app.includes('ORGANIC_V68,ORGANIC_V71]'),'V71 pack not integrated');
const builder=readFileSync('tools/build-standalone.py','utf8');
assert(builder.includes('window.__gameverseOrganicArt71')&&builder.includes('35K_Alchemy_V71_Offline.html'),'standalone missing V71');
console.log('V71 VALID: 40 new elements, 40 fixed recipes, 40 unique SVG illustrations, catalog 5212/13549');
