# 35K Alchemy — V71, Batch 01/200

This batch adds 40 curated elements, not 200. The 200-element target is a quality goal spread across editorial review and testing.

- V70 baseline 5,172 unique elements / 13,509 unordered recipes.
- V71 Batch 01 = 40 new elements / 40 new fixed recipes / 40 dedicated SVG vector drawings.
- Expected updated totals = 5,212 elements / 13,549 recipes.
- The older V69/V70 SVG asset cleanup remains complete.
- New elements are added only to the Classic catalog. Family Only campaign content is intentionally unchanged unless an explicit reachable family rule is added in a later batch.
- All new combinations use existing elements; no backwards references or changes to prior pair outcomes.
- Distinct named SVGs were vectorized from the curated original 40-icon gallery, with silhouettes tested in Dark and Light themes. At 35px, individual subjective recognition must still be reviewed on device.
- Use `node tools/validate-v71.mjs` after import to check catalog counts, duplicate names and recipes, reachability, art hashes, and embedded SVG parity.
- The HTML build integrates `ORGANIC_V71` and `ORGANIC_ART_V71`, and remains offline and fullscreen.
- Android signature `com.joaogdbg.alchemy35k` and the persistent `latest` Release URL remain unchanged.
- Future batches: add ~40 high-quality discoveries per review stage until 200 have been added, then repeat expansion cycles. Prioritize recognizable console/game content as well as natural and cultural families.

No claim that all 200 elements are complete. The full Android release must pass GitHub Actions before sharing a new APK as updated.
