#!/usr/bin/env python3
"""Curated V50 new-first expansion: 12 unique equipment concepts, two organic recipes per item."""
import json,pathlib,hashlib,html,collections
root=pathlib.Path(__file__).resolve().parents[1];D=json.loads((root/'shared/v50-base-catalog.json').read_text())
ids={x['name']:x['id'] for x in D['items']};classics=dict(D['recipes'])
# Names, descriptions and alternatives are editorial, NOT generated randomly at game runtime.
plan=[
 ('Weather Sensor','technology','A compact sensor for wind, pressure and approaching storms.',('Sensor','Forecast'),('Sensor','Storm')),
 ('Rain Sensor','technology','A small outdoor detector that notices the first raindrops.',('Sensor','Rain'),('Sensor','Drizzle')),
 ('Ocean Sensor','technology','A buoy-sized instrument for tracking changing sea conditions.',('Sensor','Sea'),('Sensor','Tide')),
 ('Solar Lantern','technology','A portable light that stores sunshine for the night.',('Solar Power','Light'),('Battery','Light')),
 ('Pocket Projector','technology','A miniature battery-powered projector for images on the go.',('Projector','Battery'),('Projector','Tool')),
 ('Portable Telescope','technology','A small travelling telescope that turns a trip into stargazing.',('Telescope','Tool'),('Telescope','Battery')),
 ('3D Scanner','technology','A camera-assisted sensor that captures the shape of an object.',('Camera','3D Printer'),('3D Printer','Sensor')),
 ('Thermal Camera','technology','A camera that reveals differences in heat.',('Camera','Heat'),('Camera','Thermometer')),
 ('Digital Compass','technology','A direction finder with electronic readout.',('Compass','Computer'),('Compass','Battery')),
 ('Smart Greenhouse','technology','A growing space monitored by a computer and sensors.',('Greenhouse','Computer'),('Greenhouse','Sensor')),
 ('Wildlife Camera','technology','A hidden camera that observes animals without disturbing them.',('Camera','Forest'),('Camera','Animal')),
 ('Underwater Camera','technology','A sealed camera that photographs life beneath the waves.',('Camera','Sea'),('Camera','Aquarium')),
]
# Hand-authored pictograms with pastel gradients, readable 100x100 small sizes.
shapes={
'weather sensor':'''<rect x="29" y="29" width="42" height="47" rx="8" fill="#F5DDAB" stroke="#977E66" stroke-width="3"/><rect x="37" y="38" width="26" height="19" rx="4" fill="#D6F0ED" stroke="#70AAA9" stroke-width="2"/><path d="M42 51l5-6 4 3 7-7" fill="none" stroke="#49778D" stroke-width="3" stroke-linecap="round"/><path d="M50 29V16m-9 0h18" stroke="#977E66" stroke-width="3"/><circle cx="50" cy="68" r="3.5" fill="#DA8E6A"/>''',
'rain sensor':'''<path d="M21 67h58l-9 10H30z" fill="#AEB6C8" stroke="#6F8298" stroke-width="3"/><rect x="42" y="43" width="16" height="24" rx="4" fill="#C9E8E8" stroke="#6B9BA0" stroke-width="3"/><path d="M50 43V28" stroke="#6F8298" stroke-width="4" stroke-linecap="round"/><path d="M28 23l-5 12m19-19-5 12m35-5-5 12m12 5-5 12" stroke="#61A9D0" stroke-width="4" stroke-linecap="round"/>''',
'ocean sensor':'''<path d="M17 73q9-9 18 0t18 0t18 0t18 0" stroke="#6DADD0" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M50 30v32" stroke="#5D6D85" stroke-width="4"/><path d="M34 60q16-25 32 0l-6 11H40z" fill="#EFA36F" stroke="#AC7557" stroke-width="3"/><circle cx="50" cy="25" r="9" fill="#E8D6A1" stroke="#977F5B" stroke-width="3"/><path d="M74 23q7 4 0 9m8-16q13 10 0 23" fill="none" stroke="#7FB9C6" stroke-width="3" stroke-linecap="round"/>''',
'solar lantern':'''<path d="M36 29q14-20 28 0" stroke="#A6835E" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M31 33h38l-6 43H37z" fill="#EFC585" stroke="#A6835E" stroke-width="3"/><rect x="39" y="40" width="22" height="28" rx="4" fill="#FFEDB0" stroke="#DBA46F" stroke-width="2"/><path d="M50 45v17M44 54h12" stroke="#FFFADE" stroke-width="4" stroke-linecap="round"/><path d="M19 31l-6 4m64-4 6 4M50 12v-5" stroke="#E4B46B" stroke-width="3"/>''',
'pocket projector':'''<rect x="18" y="43" width="61" height="28" rx="8" fill="#A5B7CD" stroke="#61748B" stroke-width="3"/><circle cx="39" cy="57" r="11" fill="#536985" stroke="#E9F0F7" stroke-width="3"/><circle cx="39" cy="57" r="5" fill="#D5E7FF"/><path d="M52 50h19M54 58h12" stroke="#E6EEF9" stroke-width="3"/><path d="M22 39V30h30" stroke="#7A8FA4" stroke-width="3" fill="none"/><path d="M79 44l12-15v55L79 71" fill="#FFF4CF" opacity=".75"/>''',
'portable telescope':'''<path d="M40 39L72 24l6 15-32 16z" fill="#90B5C2" stroke="#536F82" stroke-width="3"/><path d="M33 45l9-5 6 13-9 5z" fill="#DB9F7A" stroke="#8B6B5B" stroke-width="3"/><path d="M53 53l-6 28M53 53l18 27M53 53l-22 16" stroke="#827D7A" stroke-width="4" stroke-linecap="round"/><circle cx="77" cy="20" r="3" fill="#EFC36C"/><path d="M17 23v13m-6-6h13" stroke="#94B9D1" stroke-width="3"/>''',
'3d scanner':'''<rect x="29" y="22" width="42" height="18" rx="4" fill="#BCC9DA" stroke="#637A94" stroke-width="3"/><circle cx="50" cy="31" r="6" fill="#3B6D96" stroke="#E7F6FB" stroke-width="2"/><path d="M37 40l-9 31M63 40l9 31" stroke="#7188A1" stroke-width="4"/><path d="M35 68l15-9 15 9v15l-15 8-15-8z" fill="#D3E8EA" stroke="#609D9F" stroke-width="2.5"/><path d="M50 59v32m-15-23 15 8 15-8" fill="none" stroke="#609D9F" stroke-width="2" stroke-linejoin="round"/>''',
'thermal camera':'''<rect x="17" y="34" width="65" height="43" rx="7" fill="#9DA6BA" stroke="#606B7F" stroke-width="3"/><rect x="27" y="42" width="36" height="27" rx="4" fill="#704E87"/><path d="M30 63q8-21 15-14t15-2v20H30z" fill="#EA755F"/><path d="M35 64q6-11 12-7t9-2" stroke="#F9C26A" stroke-width="4" fill="none"/><circle cx="71" cy="54" r="4" fill="#D1E6E6"/><path d="M31 34l5-7h15l5 7" fill="#E4BDA2" stroke="#697687" stroke-width="2"/>''',
'digital compass':'''<circle cx="49" cy="51" r="30" fill="#C8DBE2" stroke="#5E8190" stroke-width="4"/><circle cx="49" cy="51" r="22" fill="#E9F4E9" stroke="#91B3A1" stroke-width="2"/><path d="M49 26v8m0 34v8M24 51h8m34 0h8" stroke="#567C8B" stroke-width="2"/><path d="M49 33l11 26-11-6-11 6z" fill="#DA807A" stroke="#A85D5C" stroke-width="2"/><path d="M49 69L38 59l11-6 11 6z" fill="#86ACCC"/><circle cx="49" cy="51" r="4" fill="#F7E3A7"/>''',
'smart greenhouse':'''<path d="M16 44L50 17l34 27v40H16z" fill="#EAF2E7" stroke="#78AAB0" stroke-width="3"/><path d="M16 44h68M50 17v67M31 33v51m38-51v51" stroke="#A5CBD1" stroke-width="3"/><path d="M34 71q-8-18-2-23t12 8q3-18 9-17t9 17q10-15 14-6t-6 21z" fill="#77B083"/><rect x="41" y="73" width="18" height="11" rx="3" fill="#D4A38A"/><circle cx="75" cy="29" r="6" fill="#F0C26E"/>''',
'wildlife camera':'''<path d="M33 23v55" stroke="#946A4F" stroke-width="9" stroke-linecap="round"/><path d="M33 38q-15-12-23-7M33 54q15-12 26-14" stroke="#946A4F" stroke-width="6" fill="none"/><path d="M58 45h25v25H58z" fill="#A3B59B" stroke="#5B795F" stroke-width="3"/><circle cx="70" cy="57" r="8" fill="#3F6171" stroke="#D0E6E5" stroke-width="3"/><circle cx="70" cy="57" r="3" fill="#D8E8F3"/><path d="M16 64q7-7 14 0m-9-8 6-6" stroke="#6FAA83" stroke-width="3" fill="none"/>''',
'underwater camera':'''<path d="M14 23q20-7 39 0t36 0" fill="none" stroke="#78B8D0" stroke-width="4"/><rect x="22" y="42" width="58" height="34" rx="7" fill="#82B9C5" stroke="#4F899D" stroke-width="3"/><rect x="30" y="35" width="22" height="10" rx="3" fill="#BDDAD9" stroke="#4F899D" stroke-width="2"/><circle cx="50" cy="58" r="13" fill="#3C7093" stroke="#E4F2ED" stroke-width="3"/><circle cx="50" cy="58" r="5" fill="#98CFE3"/><circle cx="85" cy="47" r="4" fill="none" stroke="#80BCD2" stroke-width="2"/><circle cx="13" cy="57" r="3" fill="none" stroke="#80BCD2" stroke-width="2"/>'''
}
plans=[];rec=[];seen=set(classics)
for n,c,summary,*options in plan:
 assert n not in ids,n
 id='organic50:'+n.lower().replace(' ','-')
 plans.append({'id':id,'name':n,'category':c,'summary':summary,'iconFamily':'organic'})
 for a,b in options:
  assert a in ids and b in ids,(n,a,b)
  k='|'.join(sorted([ids[a],ids[b]]))
  assert k not in seen,(n,a,b,'collision')
  seen.add(k);rec.append([ids[a],ids[b],id])
assert len(plans)==12 and len(rec)==24
S='''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100" height="100" aria-hidden="true"><ellipse cx="50" cy="92" rx="30" ry="3" fill="#60666D" opacity=".18"/><path d="M13 16v10M8 21h10" fill="none" stroke="#E1B98A" stroke-width="2.6" stroke-linecap="round"/>'''
art={}
for it in plans:
 name=it['name'].lower()
 assert name in shapes
 art[name]=S+shapes[name]+'</svg>'
assert len(set(hashlib.sha256(x.encode()).hexdigest() for x in art.values()))==12
(root/'client/src/organic-pack-v50.js').write_text('export const ORGANIC_V50 = '+json.dumps({'items':plans,'recipes':rec},ensure_ascii=False,separators=(',',':'))+';\n')
(root/'client/src/organic-art-v50.js').write_text('export const ORGANIC_ART_V50 = '+json.dumps(art,ensure_ascii=False,separators=(',',':'))+';\n')
(root/'shared/v50-expansion-report.json').write_text(json.dumps({'newItems':plans,'newRecipes':rec,'uniqueArtwork':len(art)},indent=2)+'\n')
print('Generated',len(plans),'new items',len(rec),'new-first recipes',len(art),'distinct SVGs')
